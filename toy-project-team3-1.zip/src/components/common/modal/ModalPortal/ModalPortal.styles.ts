import styled from 'styled-components';

export const Overlay = styled.div<{ $blockClick?: boolean }>`
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 2;
  background-color: ${({ $blockClick, theme }) =>
    $blockClick && theme.colors.opacity.darken1};
`;
