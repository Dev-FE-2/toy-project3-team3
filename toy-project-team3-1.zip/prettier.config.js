export default {
  semi: true,
  singleQuote: true,
  useTabs: false,
  tabWidth: 2,
  printWidth: 80,
  arrowParens: 'always',
  trailingComma: 'all',
  quoteProps: 'as-needed',
};
